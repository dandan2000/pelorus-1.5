# demo

Scripts to demonstrate pelorus functionality live here.

## demo-tekton

Although the pelorus functionality isn't merged yet, you can set up a basic python tekton pipeline with this script.

It takes a single argument which is the downstream/fork URL you'll be pushing to.

## demo.sh

See the [demo docs in the official pelorus documentation.](https://pelorus.readthedocs.io/en/latest/Demo/)
