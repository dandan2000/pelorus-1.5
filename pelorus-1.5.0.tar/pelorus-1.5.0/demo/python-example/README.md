# python-example

This contains a very simple python HTTP server that just serves the `response.txt` file.

This file can easily be appended to, in order to demonstrate pipelines deploying changes.
