# tekton-demo-setup

This contains OpenShift resources to set up a tekton python demo. 
